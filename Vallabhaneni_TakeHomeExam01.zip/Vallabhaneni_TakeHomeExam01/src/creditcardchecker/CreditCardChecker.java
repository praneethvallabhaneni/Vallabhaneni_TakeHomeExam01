/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creditcardchecker;

/**
 *
 * @author Praneeth Vallabhaneni
 */
import java.util.Scanner;

public class CreditCardChecker {

	public static void main(String[] args) {
		// TODO code application logic here
		System.out.println("Enter a credit card number as a long integer: ");
		Scanner sc = new Scanner(System.in);
		long number = Long.parseLong(sc.nextLine());
		if (isValid(number)) {
			System.out.println(String.valueOf(number) + " is valid");
		}
		else {
			System.out.println(String.valueOf(number) + " is invalid");
		}
	}
	
	/** Return true if the card number is valid */
	public static boolean isValid(long number) {
		int sizeCard = getSize(number);
		if (!(sizeCard >= 13 && sizeCard <= 16)) return false;
		else{
			
			long singleDig = getPrefix(number, 1);
			long DoubleDig = getPrefix(number, 2);
			if ((singleDig < 4 && singleDig > 6) && DoubleDig != 37) return false;
			
			int totalSum = sumOfDoubleEvenPlace(number) + sumOfOddPlace(number);
			
			if (totalSum % 10 == 0) return true;
			else {
				return false;
			}
		}
	}
	

	/** Get the result from Step 2 */
	public static int sumOfDoubleEvenPlace(long number) {
		
	    boolean isSecond = false;
	    int digit = 0;
	    int answer = 0;
	    
	    while (number > 0) {
	    	if (isSecond) {
	    		digit = (int) (number%10);
	    		digit = getDigit(digit*2);
	    		answer += digit;
	    	}
	    	number /= 10;
	    	isSecond = !isSecond;
	    } 
	    return answer;
	}
	
	/** Return this number if it is a single digit, otherwise,
	* return the sum of the two digits */
	public static int getDigit(int number) {
		if (number <= 9) return number;
		else {
			int temp = 0;
			while(number > 0) {
				temp += number%10;
				number /= 10;
			}
			return getDigit(temp);
		}
	}
	
	/** Return sum of odd-place digits in number */
	public static int sumOfOddPlace(long number) {
		boolean isOdd = true;
	    int answer = 0;
	    while (number > 0) {
	  
	    	if (isOdd) {
	    		answer += (int) (number%10);
	    	}
	    	number /= 10;
	    	isOdd = !isOdd;
	    } 
	    return answer;
	}
	
	/** Return true if the digit d is a prefix for number */
	public static boolean prefixMatched(long number, int d) {
		String num_s = String.valueOf(number);
		String d_s = String.valueOf(d);
		return num_s.startsWith(d_s);
	}
	
	/** Return the number of digits in d */
	public static int getSize(long d) {
		int count = 0;
		for(; d != 0; d/=10, ++count) {   
        }
		return count;
	}
	
	/** Return the first k number of digits from number. If the
	* number of digits in number is less than k, return number. */
	public static long getPrefix(long number, int k) {
		if (getSize(number) < k) return number;
		else {
			String num_s = String.valueOf(number);
			return Long.valueOf(num_s.substring(0, k)).longValue();
		}
	}
}


