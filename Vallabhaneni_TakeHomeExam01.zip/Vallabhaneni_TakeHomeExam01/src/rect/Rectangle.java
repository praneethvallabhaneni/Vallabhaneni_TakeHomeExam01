/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rect;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class Rectangle {
    
    int one;
    int two;
    int three;
    int four;

    public Rectangle(int one, int two, int three, int four) {
        this.one = one;
        this.two = two;
        this.three = three;
        this.four = four;
    }
}
