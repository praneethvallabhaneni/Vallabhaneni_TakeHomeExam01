/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pentagon;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class pentagon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the length from the center to a vertex: ");
        double length = input.nextDouble();
        
        double side = 2*length* Math.sin(Math.PI/5);
        
        double area = (5*Math.pow(side, 2)/(4*Math.tan(Math.PI/5)));
        System.out.println("The area of the pentagon is "+String.format("%.2f", area));
        
    }
    
}
