/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SSN;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class SSNDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter SSN in DDD-DD-DDDD format: ");
        
        String ssn = input.nextLine();
        
        String ssnRegex = "^[0-9]{3}-[0-9]{2}-[0-9]{4}$";
        
        if(ssn.matches(ssnRegex)){
            System.out.println(ssn+" is a valid social security number");
        }
        else{
            System.out.println(ssn+" is an invalid social security number");
        }

    }
    
}
