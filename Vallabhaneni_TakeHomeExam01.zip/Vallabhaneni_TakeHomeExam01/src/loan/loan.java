/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loan;

import java.util.ArrayList;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class loan {
    
    int payment;
    double interest;
    double principal;
    double balance;
    
    ArrayList amortization = new ArrayList<>();
    
    public loan(int payment, double interest, double principal, double balance) {
        this.payment = payment;
        this.interest = interest;
        this.principal = principal;
        this.balance = balance;
    }

    public loan() {
    }
    

    public double getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }

    public double getPrincipal() {
        return principal;
    }

    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public ArrayList getAmortization() {
        return amortization;
    }

    public void setAmortization(ArrayList amortization) {
        this.amortization = amortization;
    }

    @Override
    public String toString() {
        return  payment + "\t\t" + interest + "\t\t" + principal + "\t\t" + balance ;
    }
    
    
    
    
}
