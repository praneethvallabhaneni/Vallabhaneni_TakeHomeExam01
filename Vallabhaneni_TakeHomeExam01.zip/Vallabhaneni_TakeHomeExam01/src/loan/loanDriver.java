/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loan;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class loanDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.print("Enter loan amount: ");
        double loanAmt = input.nextInt();
        input.nextLine();
        System.out.print("Enter number of years: ");
        double months = input.nextDouble() * 12;
        input.nextLine();
        System.out.print("Enter Annual Interest Rate: ");
        double ir = input.nextDouble();
        ir = ir / (12 * 100);
//        ir = ir/100;
        input.nextLine();

        ArrayList<loan> amortization = new ArrayList<>();
        

        double monthlyPayment = Math.round((loanAmt * (((ir) * Math.pow((1 + (ir)), months)) / ((Math.pow((1 + (ir)), months)) - 1)))*100.0)/100.0;
        System.out.println("Monthly Payment: " + monthlyPayment);
        double totalPaid = Math.round(loanAmt*100.0)/100.0;
        double interestAmt = Math.round(loanAmt*ir*100.0)/100.0;
        double principalAmt = Math.round((monthlyPayment - interestAmt)*100.0)/100.0;
        double balance = Math.round((loanAmt - monthlyPayment+interestAmt)*100.0)/100.0;
        
        
        for (int i = 0; i < months; i++) {
            if(balance<0){
                loan l = new loan(i+1,interestAmt,principalAmt, 0);
                amortization.add(l);
            }
                
            
            else{
            loan l = new loan(i+1,interestAmt,principalAmt, balance);
            totalPaid += interestAmt;
            amortization.add(i,l);
            loanAmt = Math.round(balance*100.0)/100.0;
            interestAmt = Math.round(loanAmt*ir*100.0)/100.0;
            balance = Math.round((loanAmt - monthlyPayment+interestAmt)*100.0)/100.0;
            principalAmt = Math.round((monthlyPayment - interestAmt)*100.0)/100.0;
            }
            
        }
        System.out.println("Total Paid: "+String.format("%.2f", totalPaid));
        System.out.println("Payment#\tInterest\tPrincipal\tBalance");
        for(loan l : amortization)
            System.out.println(l.toString());

    }

}
