/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeoCalender;
import java.util.GregorianCalendar;
import static javax.swing.UIManager.get;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class calender {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        GregorianCalendar gc = new GregorianCalendar();
        System.out.println("Current Year: "+ gc.get(GregorianCalendar.YEAR)+" Current month: "+gc.get(GregorianCalendar.MONTH)+" Current Day: "+gc.get(GregorianCalendar.DAY_OF_MONTH));
        gc.setTimeInMillis(1234567898765L);
        System.out.println("Current Year: "+ gc.get(GregorianCalendar.YEAR)+" Current month: "+gc.get(GregorianCalendar.MONTH)+" Current Day: "+gc.get(GregorianCalendar.DAY_OF_MONTH));
    }
    
}
