/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string14;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class string {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner input = new Scanner(System.in);
        System.out.print("Enter String 1");
        String str1 = input.nextLine();
        System.out.print("Enter String 2:");
        String str2 = input.nextLine();
        int count = 0;
         for (int i = 0; i <= str1.length() - str2.length(); i++) {   
            int j;
            for (j = 0; j < str2.length(); j++) {
                if (str1.charAt(i + j) != str2.charAt(j)) {
                    break;
                }
            }
            if (j == str2.length()) {                
                count++;                
                j = 0;                
            }            
        }        
      
        System.out.println("The number of occurrences of "+str2+" in the above string are "+count);

    }

}
