/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string14;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class string {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner input = new Scanner(System.in);
        System.out.print("Enter String 1");
        String[] str1 = input.nextLine().split(" ");
        System.out.print("Enter String 2:");
        String str2 = input.nextLine();
        int count = 0;
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].equalsIgnoreCase(str2)) {
                count++;
            }

        }
        System.out.println("The number of occurrences of "+str2+" in the above string are "+count);

    }

}
