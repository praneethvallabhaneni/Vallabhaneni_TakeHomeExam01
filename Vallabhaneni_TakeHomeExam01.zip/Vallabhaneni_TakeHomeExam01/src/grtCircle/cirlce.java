/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grtCircle;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class cirlce {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner input = new Scanner(System.in);
        System.out.println("Enter point 1 (latitude and longitude) in degrees: ");
        String[] c1 = input.nextLine().split(",");
        c1[1]= c1[1].trim();
        System.out.println("Enter point 2 (latitude and longitude) in degrees: ");
        String[] c2 = input.nextLine().split(",");
        c2[1]=c2[1].trim();
        double radius = 6371.01;
        
        double num1 = Math.sin(Math.toRadians(Double.parseDouble(c1[0])))* Math.sin(Math.toRadians(Double.parseDouble(c2[0])));
        
        double num2 = Math.cos(Math.toRadians(Double.parseDouble(c1[0])))*Math.cos(Math.toRadians(Double.parseDouble(c2[0])))*(Math.cos(Math.toRadians(Double.parseDouble(c1[1]))-Math.toRadians(Double.parseDouble(c2[1]))));
        double ans =radius* Math.acos(num1+num2);
        System.out.println("The distance between the two points is "+ans+" Km");

    }

}
