/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fan;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class fan {
    
    final int SLOW =1;
    final int MEDIUM=2;
    final int FAST=3;
    
    private int speed;
    private boolean on;
    private double radius;
    private String color;

    public fan() {
        
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        if(on == true){
            return "Fan Speed: "+speed+"\t Fan Color: "+color+"\tFan Radius: "+radius;
        }
        else{
            return "Fan is off\tFan Color: "+color+"\tFan Radius: "+radius;
        }
    }
    
    
    
    
}
