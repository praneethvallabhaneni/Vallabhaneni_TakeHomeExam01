/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fan;

import java.util.Scanner;

/**
 *
 * @author Praneeth Vallabhaneni
 */
public class FanDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter fan speed Slow/Medium/Fast:");
        String speed = input.nextLine();
        System.out.println("Enter fan color:");
        String color=input.nextLine();
        System.out.println("Do you want to on the fan(yes/no)?:");
        boolean on;
        if (input.nextLine().equalsIgnoreCase("yes"))
            on=true;
        else
            on=false;
        System.out.println("Enter fan's radius:");
        double radius = input.nextDouble();
        
        fan f = new fan();
        f.setColor(color);
        f.setOn(on);
        f.setRadius(radius);
        if(speed.equalsIgnoreCase("Slow"))
            f.setSpeed(f.SLOW);
        else if(speed.equalsIgnoreCase("Medium"))
            f.setSpeed(f.MEDIUM);
        else 
            f.setSpeed(f.FAST);
        
        System.out.println("------Using toString------");    
        System.out.println(f.toString());
        
        System.out.println("------Using Getters------");
        if(on == true){
            System.out.println("Fan Speed: "+f.getSpeed()+"\t Fan Color: "+f.getColor()+"\tFan Radius: "+f.getRadius());
        }
        else{
            System.out.println("Fan is off\tFan Color: "+f.getColor()+"\tFan Radius: "+f.getRadius());
        }
    }
    
}
