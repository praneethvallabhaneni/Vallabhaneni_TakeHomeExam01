/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MinSales;

/**
 *
 * @author Praneeth Vallabhaneni
 */
    /**
     * @param args the command line arguments
     */
    public class MinSales {
	
	public static int getCommision(double base) {
		if (base <= 5000) return 8;
		if (base > 5000 && base <= 10000) return 10;
		if (base > 10000) return 12;
		return 0;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double pay = 5000;
		
		double sale = 0.0;
		
		double saleQuantity = 1;
		
		do {
			sale += saleQuantity;
			pay += getCommision(sale)*(saleQuantity)/100;
		}while (pay <= 30000.00);
		
		System.out.println("Minimum Sales amount required would be: " + String.valueOf(sale) + " " + String.valueOf(pay));
	}
}

